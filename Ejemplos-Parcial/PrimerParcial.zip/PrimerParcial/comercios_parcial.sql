-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 10-10-2018 a las 22:03:22
-- Versión del servidor: 10.1.34-MariaDB
-- Versión de PHP: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `comercios_parcial`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comercios`
--

CREATE TABLE `comercios` (
  `id` int(11) NOT NULL,
  `denominacion` varchar(60) NOT NULL,
  `direccion` varchar(80) NOT NULL,
  `lat` float(10,6) NOT NULL,
  `lng` float(10,6) NOT NULL,
  `tipo` varchar(30) NOT NULL,
  `imagen` varchar(512) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `comercios`
--

INSERT INTO `comercios` (`id`, `denominacion`, `direccion`, `lat`, `lng`, `tipo`, `imagen`) VALUES
(1, 'Café la Plaza', 'Calle 18 esq 11, 6360, General Pico, La Pampa, Argentina', -35.657772, -63.753052, 'restaurant', 'imagenes/cafe_la_plaza.jpg'),
(2, 'El Despacho', 'calle 20 458, 6360, General Pico, La Pampa, Argentina', -35.657310, -63.753937, 'bar', 'imagenes/el_despacho.jpg'),
(3, 'Médano', 'Calle 11 Nº1185, Gral. Pico, La Pampa', -35.656952, -63.752964, 'bar', 'imagenes/no-imagen.jpg'),
(4, 'Parrilla siete 3 siete', 'Calle 18 747, L6360 Gral. Pico, La Pampa', -35.659561, -63.753014, 'restaurant', 'imagenes/no-imagen.jpg'),
(5, 'Capitano Craft', 'Calle 17 898, L6360 Gral. Pico, La Pampa', -33.879917, -63.753414, 'bar', 'imagenes/cap_craf.jpg'),
(6, 'Capitano Bar', 'Calle 17 911, L6360 Gral. Pico, La Pampa', -35.660671, -63.753414, 'restaurant', 'imagenes/cap_bar.png'),
(7, 'Viejo Gomez', 'Calle 17 873, Gral. Pico, La Pampa', -35.661289, -63.753502, 'restaurant', 'imagenes/no-imagen.jpg'),
(8, 'Bar Bendito', 'Calle 18 848, Gral. Pico, La Pampa', -35.661331, -63.752811, 'bar', 'imagenes/no-imagen.jpg'),
(9, 'Plan B resto bar', 'Calle 18, Gral. Pico, La Pampa', -35.661556, -63.752884, 'bar', 'imagenes/no-imagen.jpg'),
(10, 'Mr. Morgan', 'Calle 19 874, Gral. Pico, La Pampa', -35.662079, -63.752934, 'bar', 'imagenes/no-imagen.jpg'),
(11, 'Confiteria Hotel Pico', 'Calle 17 1013, Gral. Pico, La Pampa', -35.660065, -63.752083, 'restaurant', 'imagenes/hotel_pico.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menu`
--

CREATE TABLE `menu` (
  `label` varchar(100) NOT NULL,
  `url` varchar(100) NOT NULL,
  `secuencia` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `menu`
--

INSERT INTO `menu` (`label`, `url`, `secuencia`) VALUES
('Inicio', '/', 1),
('Comercios', '/todos', 2),
('Restaurantes', '/restaurantes', 3),
('Bares', '/bares', 4);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `comercios`
--
ALTER TABLE `comercios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `comercios`
--
ALTER TABLE `comercios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
