/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.primerparcial;

/**
 *
 * @author dinoc
 */


import spark.Request;
import spark.Response;
import spark.Route;
import java.util.List;
import java.util.ArrayList;

import java.util.HashMap; 
import spark.ModelAndView;
import spark.template.velocity.VelocityTemplateEngine;


public class IndexController {
    
    public static Route 
        getIndex = (Request req, Response res) -> {
    
            HashMap model = new HashMap();
            model.put("menu", armarMenu());  
            model.put("menuActivo", "/");   
            model.put("template", "templates/index.vsl");
            
            
            return new VelocityTemplateEngine().render(new ModelAndView(model, "templates/layout.vsl")); 
        };
    
    private static List<Menu> armarMenu(){
        MenuDAO mDAO = new MenuDAO();
        List<Menu> menu = mDAO.getAll();
        return menu;    
    }
}
