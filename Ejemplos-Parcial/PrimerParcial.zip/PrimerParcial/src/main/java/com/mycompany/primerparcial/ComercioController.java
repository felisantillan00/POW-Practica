package com.mycompany.primerparcial;


import spark.Request;
import spark.Response;
import spark.Route;
import java.util.List;
import java.util.ArrayList;

import java.util.HashMap; 
import spark.ModelAndView;
import spark.template.velocity.VelocityTemplateEngine;


public class ComercioController {
    
    public static Route 
        getBares = (Request req, Response res) -> {
     
            HashMap model = new HashMap();
            ComercioDAO cDAO = new ComercioDAO();
            List<Comercio> bares = cDAO.getBares();
            model.put("comercios", bares);
            model.put("menu", armarMenu());
            model.put("menuActivo", "/bares");   
            model.put("template", "templates/main.vsl");
            
            return new VelocityTemplateEngine().render(new ModelAndView(model, "templates/layout.vsl")); 
        }; 
   
    public static Route 
        getRestaurantes = (Request req, Response res) -> {
     
            HashMap model = new HashMap();
            ComercioDAO cDAO = new ComercioDAO();
            List<Comercio> restaurantes = cDAO.getRestaurantes();
            model.put("comercios", restaurantes);
            model.put("menu", armarMenu());
            model.put("menuActivo", "/restaurantes");   
            model.put("template", "templates/main.vsl");
            
            return new VelocityTemplateEngine().render(new ModelAndView(model, "templates/layout.vsl")); 
        }; 
   
    public static Route 
        getAll = (Request req, Response res) -> {
     
            HashMap model = new HashMap();
            ComercioDAO cDAO = new ComercioDAO();
            List<Comercio> all = cDAO.getAll();
            model.put("comercios", all);
            model.put("menu", armarMenu());
            model.put("menuActivo", "/todos"); 
            model.put("template", "templates/main.vsl");
            
            return new VelocityTemplateEngine().render(new ModelAndView(model, "templates/layout.vsl")); 
        }; 
    public static Route 
        getOneInstance = (Request req, Response res) -> {
     
            HashMap model = new HashMap();
            ComercioDAO cDAO = new ComercioDAO();
            List<Comercio> instance = cDAO.get(req.queryParams("id"));
            model.put("instance", instance.get(0));
            
            return new VelocityTemplateEngine().render(new ModelAndView(model, "templates/comercio.vsl")); 
        }; 
    
    private static List<Menu> armarMenu(){
        MenuDAO mDAO = new MenuDAO();
        List<Menu> menu = mDAO.getAll();
        return menu;    
    }
}


