package com.mycompany.primerparcial;

/**
 * Modelo de Comercio
 * @author dinoc
 */
    
import lombok.Data;

@Data
public class Comercio {
    //Atributos
    private int id;//ID que representa al comercio
    private String denominacion;//Denominacion (Nombre de comercio)
    private String direccion;//Denominacion (Nombre de comercio)
    private String tipo;//Tipo de comercio ['restaurant','bar']
    private String imagen;//Url relativa de la imagen
    //Cordenadas de ubicacion
    private float lat;//Latitud
    private float lng;//Longitud
    //
}
