package com.mycompany.primerparcial;

/*
 * DAO para Comercio
 */

/**
 *
 * @author dinoc
 */

import java.util.List;
import org.sql2o.*;

public class MenuDAO {
   private List<Menu> menu;
    
    public List<Menu> getAll() {    
        Sql2o sql2o = new Sql2o("jdbc:mysql://localhost:3306/comercios_parcial", "root", "adminadmin");
        try (Connection con = sql2o.open()) {
            String sql = "SELECT * FROM menu ORDER BY secuencia";
            menu = con
                .createQuery(sql)
                .executeAndFetch(Menu.class);
        }
        return menu;
    }
}
