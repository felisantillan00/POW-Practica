package com.mycompany.primerparcial;

/**
 * Modelo de Comercio
 * @author dinoc
 */
    
import lombok.Data;

@Data
public class Menu {
    //Atributos
    private String label;//ID que representa al comercio
    private String url;//Denominacion (Nombre de comercio)
    private int secuencia;//Denominacion (Nombre de comercio)
}
