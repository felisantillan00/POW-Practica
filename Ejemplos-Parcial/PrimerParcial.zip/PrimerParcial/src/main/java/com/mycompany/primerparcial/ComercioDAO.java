package com.mycompany.primerparcial;

/*
 * DAO para Comercio
 */

/**
 *
 * @author dinoc
 */

import java.util.List;
import org.sql2o.*;

public class ComercioDAO {
   private List<Comercio> comercios;
    
    public List<Comercio> getBares() {
        
        Sql2o sql2o = new Sql2o("jdbc:mysql://localhost:3306/comercios_parcial", "root", "adminadmin");
     
        try (Connection con = sql2o.open()) {
            String sql = "SELECT * FROM comercios WHERE tipo = :tipo";
            comercios = con
                .createQuery(sql)
                .addParameter("tipo", "bar")
                .executeAndFetch(Comercio.class);
        }
        return comercios;
    }
    
    public List<Comercio> getRestaurantes() {    
        Sql2o sql2o = new Sql2o("jdbc:mysql://localhost:3306/comercios_parcial", "root", "adminadmin");
        try (Connection con = sql2o.open()) {
            String sql = "SELECT * FROM comercios WHERE tipo = :tipo";
            comercios = con
                .createQuery(sql)
                .addParameter("tipo", "restaurant")
                .executeAndFetch(Comercio.class);
        }
        return comercios;
    }
    
    public List<Comercio> getAll() {    
        Sql2o sql2o = new Sql2o("jdbc:mysql://localhost:3306/comercios_parcial", "root", "adminadmin");
        try (Connection con = sql2o.open()) {
            String sql = "SELECT * FROM comercios";
            comercios = con
                .createQuery(sql)
                .executeAndFetch(Comercio.class);
        }
        return comercios;
    }
    public List<Comercio> get(String Id) {    
        Sql2o sql2o = new Sql2o("jdbc:mysql://localhost:3306/comercios_parcial", "root", "adminadmin");
        try (Connection con = sql2o.open()) {
            String sql = "SELECT * FROM comercios WHERE id = :id";
            comercios = con
                .createQuery(sql)
                .addParameter("id", Id)
                .executeAndFetch(Comercio.class);
        }
        return comercios;
    }
}
