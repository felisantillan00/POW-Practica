package com.mycompany.primerparcial;

import static spark.Spark.*; 

/**
 *
 * @author dinoc
 */
public class Main {   
    public static void main(String[] args) {
            staticFiles.location("/public");
            get("/", IndexController.getIndex);  
            get("/todos", ComercioController.getAll);  
            get("/bares", ComercioController.getBares);  
            get("/restaurantes", ComercioController.getRestaurantes); 
            get("/getComercio", ComercioController.getOneInstance);
    }
}
